# Login en PHP y MySQL Versión 3

En este proyecto utilizamos varios componentes, para la parte visual se usa Bootstrap, para las alertas utilizamos SweetAlert y para los iconos utilizamos Font Awesome, recuerda que tanto Bootstrap como SweetAlert requieren de jquery para funcionar (el proyecto usa la version 3.1.1 de jquery).

El login valida que el usuario y la clave sean correctas, agregue una animacion que se muestra mientras el cliete espera una respuesta del servidor, normalmente en local no se nota pero cuando el proyecto se sube a un servidor real el load si tiene tiempo de mostrarse, agregue ademas el manejo de roles, ademas las paginas donde se redirecciona valida si la sesion iniciada tiene permisos para ver la pagina, para finalizar agregue un boton de cerrar sesion, y el archivo de index donde esta el login valida si existe una sesion y si es asi redirecciona a la pagina que corresponde la sesion. 

# Usuario de prueba
user:  administrador@itdelicias.edu.mx 
clave: 123

# Gracias :) 
